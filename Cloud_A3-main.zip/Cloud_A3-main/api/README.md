# node express api for a3 project

## Environment variables
Create a '.env' in the root folder and add these variables (to start with)

```
PORT=3000
```

---
Then run 
```
npm i
```
from the root folder to install the packages required. 

### Happy noding!
